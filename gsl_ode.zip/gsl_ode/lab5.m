%% Exercise 1 TODO
!./exercise1 45 1 > log.txt
res = load('log.txt');
!rm log.txt

%% Exercise 2
%TODO: Why does this result suck????
!./exercise2 2 60 > log.txt
res = load('log.txt');
figure;
t = res(:,1);
y1 = res(:,2);
y2 = res(:,3);
y3 = res(:,4);
plot(t, y1, t, y2, t, y3);
xlabel('time'); ylabel('y_i');
legend('y1', 'y2', 'y3');

!rm log.txt

!./exercise2 2 360 > log.txt
res = load('log.txt');
!rm log.txt

!./exercise2 4 60 > log.txt
res = load('log.txt');
!rm log.txt

!./exercise2 4 360 > log.txt
res = load('log.txt');
!rm log.txt

%% Exercise 3
!./exercise3 3 10 > log.txt
res = load('log.txt');
!rm log.txt

!./exercise3 3 10 > log.txt
res = load('log.txt');
!rm log.txt

%% Exercise 4
!./exercise4 > log.txt
res = load('log.txt');
